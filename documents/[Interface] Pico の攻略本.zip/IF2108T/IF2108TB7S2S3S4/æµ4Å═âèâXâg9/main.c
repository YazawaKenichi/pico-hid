/*
#define MK_PTR_RW(x) (*(volatile int*)(x))

#define _RW   0x0000
#define _XOR  0x1000
#define _SET  0x2000
#define _CLR  0x3000

#define STK_CSR MK_PTR_RW(0xE000E010)
#define STK_RVR MK_PTR_RW(0xE000E014)
#define STK_CVR MK_PTR_RW(0xE000E018)


#define RESETS_BASE                 0x4000C000
#define RESETS_RESET_CLR       MK_PTR_RW(RESETS_BASE+0x0+_CLR)
#define RESETS_RESET_DONE_RW   MK_PTR_RW(RESETS_BASE+0x8+_RW)

#define CLOCKS_BASE                 0x40008000
#define CLK_SYS_RESUS_CTRL_RW       MK_PTR_RW(CLOCKS_BASE+0x78+_RW)
#define CLK_REF_CTRL_RW             MK_PTR_RW(CLOCKS_BASE+0x30+_RW)
#define CLK_SYS_CTRL_RW             MK_PTR_RW(CLOCKS_BASE+0x3C+_RW)
#define CLK_PERI_CTRL_RW            MK_PTR_RW(CLOCKS_BASE+0x48+_RW)


#define SIO_BASE                    0xD0000000
#define SIO_GPIO_OE_CLR             MK_PTR_RW(SIO_BASE+0x28)
#define SIO_GPIO_OUT_CLR            MK_PTR_RW(SIO_BASE+0x18)
#define SIO_GPIO_OUT_XOR            MK_PTR_RW(SIO_BASE+0x1C)
#define SIO_GPIO_OE_SET             MK_PTR_RW(SIO_BASE+0x24)


#define PADS_BANK0_BASE             0x4001C000

#define PADS_BANK0_GPIO0_RW         MK_PTR_RW(PADS_BANK0_BASE+0x04+_RW)
#define PADS_BANK0_GPIO0_XOR        MK_PTR_RW(PADS_BANK0_BASE+0x04+_XOR)

#define PADS_BANK0_GPIO25_RW        MK_PTR_RW(PADS_BANK0_BASE+0x68+_RW)
#define PADS_BANK0_GPIO25_XOR       MK_PTR_RW(PADS_BANK0_BASE+0x68+_XOR)


#define XOSC_BASE                   0x40024000
#define XOSC_CTRL_RW                MK_PTR_RW(XOSC_BASE+0x00+_RW)
#define XOSC_STARTUP_RW             MK_PTR_RW(XOSC_BASE+0x0C+_RW)
#define XOSC_CTRL_SET               MK_PTR_RW(XOSC_BASE+0x00+_SET)
#define XOSC_STATUS_RW              MK_PTR_RW(XOSC_BASE+0x04+_RW)

#define IO_BANK0_BASE               0x40014000

#define IO_BANK0_GPIO0_CTRL_RW      MK_PTR_RW(IO_BANK0_BASE+0x004+_RW)

#define IO_BANK0_GPIO25_CTRL_RW     MK_PTR_RW(IO_BANK0_BASE+0x0CC+_RW)


#define PIO0_BASE                   0x50200000
#define PIO0_CTRL_RW                MK_PTR_RW(PIO0_BASE+0x000+_RW)
#define PIO0_FSTAT_RW               MK_PTR_RW(PIO0_BASE+0x004+_RW)
#define PIO0_TXF0_RW                MK_PTR_RW(PIO0_BASE+0x010+_RW)
#define PIO0_INSTR_MEM0_RW          MK_PTR_RW(PIO0_BASE+0x048+_RW)
#define PIO0_INSTR_MEM1_RW          MK_PTR_RW(PIO0_BASE+0x04C+_RW)
#define PIO0_INSTR_MEM2_RW          MK_PTR_RW(PIO0_BASE+0x050+_RW)
#define PIO0_INSTR_MEM3_RW          MK_PTR_RW(PIO0_BASE+0x054+_RW)
#define PIO0_INSTR_MEM4_RW          MK_PTR_RW(PIO0_BASE+0x058+_RW)
#define PIO0_INSTR_MEM5_RW          MK_PTR_RW(PIO0_BASE+0x05C+_RW)
#define PIO0_INSTR_MEM6_RW          MK_PTR_RW(PIO0_BASE+0x060+_RW)
#define PIO0_INSTR_MEM7_RW          MK_PTR_RW(PIO0_BASE+0x064+_RW)
#define PIO0_INSTR_MEM8_RW          MK_PTR_RW(PIO0_BASE+0x068+_RW)
#define PIO0_INSTR_MEM9_RW          MK_PTR_RW(PIO0_BASE+0x06C+_RW)
#define PIO0_INSTR_MEM10_RW         MK_PTR_RW(PIO0_BASE+0x070+_RW)
#define PIO0_INSTR_MEM11_RW         MK_PTR_RW(PIO0_BASE+0x074+_RW)
#define PIO0_INSTR_MEM12_RW         MK_PTR_RW(PIO0_BASE+0x078+_RW)
#define PIO0_INSTR_MEM13_RW         MK_PTR_RW(PIO0_BASE+0x07C+_RW)
#define PIO0_INSTR_MEM14_RW         MK_PTR_RW(PIO0_BASE+0x080+_RW)
#define PIO0_INSTR_MEM15_RW         MK_PTR_RW(PIO0_BASE+0x084+_RW)
#define PIO0_INSTR_MEM16_RW         MK_PTR_RW(PIO0_BASE+0x088+_RW)
#define PIO0_INSTR_MEM17_RW         MK_PTR_RW(PIO0_BASE+0x08C+_RW)
#define PIO0_INSTR_MEM18_RW         MK_PTR_RW(PIO0_BASE+0x090+_RW)
#define PIO0_INSTR_MEM19_RW         MK_PTR_RW(PIO0_BASE+0x094+_RW)
#define PIO0_INSTR_MEM20_RW         MK_PTR_RW(PIO0_BASE+0x098+_RW)
#define PIO0_INSTR_MEM21_RW         MK_PTR_RW(PIO0_BASE+0x09C+_RW)
#define PIO0_SM0_CLKDIV_RW          MK_PTR_RW(PIO0_BASE+0x0C8+_RW)
#define PIO0_SM0_PINCTRL_RW         MK_PTR_RW(PIO0_BASE+0x0DC+_RW)
#define PIO0_SM1_CLKDIV_RW          MK_PTR_RW(PIO0_BASE+0x0E0+_RW)
#define PIO0_SM1_PINCTRL_RW         MK_PTR_RW(PIO0_BASE+0x0F4+_RW)

#define PIO0_SM0_INSTR_RW           MK_PTR_RW(PIO0_BASE+0x0D8+_RW)
#define PIO0_SM1_INSTR_RW           MK_PTR_RW(PIO0_BASE+0x0F0+_RW)
*/

#include "define.h"

void sm_putc(int ch)
{
	while((PIO0_FSTAT_RW & (1<<(16+0)))!=0) ;
	PIO0_TXF0_RW = ch;
}

void sm_puts(char *s)
{
	while(*s){
		sm_putc(*s);
		s++;
	}
}


static void clock_init ( void )
{
    CLK_SYS_RESUS_CTRL_RW = 0;
    XOSC_CTRL_RW          = 0xAA0;      //1 - 15MHZ
    XOSC_STARTUP_RW       = 47;         //straight from the datasheet
    XOSC_CTRL_SET         = 0xFAB000;   //enable
    while((XOSC_STATUS_RW & 0x80000000)==0);
    CLK_REF_CTRL_RW       = 2;          //XOSC
    CLK_SYS_CTRL_RW       = 0;          //reset/clk_ref
}

void reset_release(void)
{
    CLK_PERI_CTRL_RW = (1<<11)|(4<<5); // enable/xosc
    
    RESETS_RESET_CLR = (1<<5); //IO_BANK0
    while((RESETS_RESET_DONE_RW & (1<<5))==0);
    
    RESETS_RESET_CLR = (1<<8); //PADS_BANK0
    while((RESETS_RESET_DONE_RW & (1<<8))==0);
    
    RESETS_RESET_CLR = (1<<22); //UART0
    while((RESETS_RESET_DONE_RW & (1<<22))==0);
    
    RESETS_RESET_CLR = (1<<10); //PIO0
    while((RESETS_RESET_DONE_RW & (1<<10))==0);
    
}

unsigned int main ( void )
{
    clock_init();
	reset_release();
	
	
	           //     .wrap_target
    PIO0_INSTR_MEM0_RW = 0xe081; //  0: set    pindirs, 1
    PIO0_INSTR_MEM1_RW = 0xe001; //  1: set    pins, 1
    PIO0_INSTR_MEM2_RW = 0xe028; //  2: set    x, 8
    PIO0_INSTR_MEM3_RW = 0x0043; //  3: jmp    x--, 3
    PIO0_INSTR_MEM4_RW = 0x80a0; //  4: pull   block
    PIO0_INSTR_MEM5_RW = 0xe000; //  5: set    pins, 0
    PIO0_INSTR_MEM6_RW = 0x6001; //  6: out    pins, 1
    PIO0_INSTR_MEM7_RW = 0x6001; //  7: out    pins, 1
    PIO0_INSTR_MEM8_RW = 0x6001; //  8: out    pins, 1
    PIO0_INSTR_MEM9_RW = 0x6001; //  9: out    pins, 1
    PIO0_INSTR_MEM10_RW = 0x6001; // 10: out    pins, 1
    PIO0_INSTR_MEM11_RW = 0x6001; // 11: out    pins, 1
    PIO0_INSTR_MEM12_RW = 0x6001; // 12: out    pins, 1
    PIO0_INSTR_MEM13_RW = 0x6001; // 13: out    pins, 1
    PIO0_INSTR_MEM14_RW = 0xe001; // 14: set    pins, 1
    PIO0_INSTR_MEM15_RW = 0x0001; // 15: jmp    1
            //     .wrap

    PIO0_SM0_CLKDIV_RW = 0x00682AAA;

    PIO0_SM0_PINCTRL_RW = (1<<26)|(1<<20)|(0<<5)|(0<<0);

    PADS_BANK0_GPIO0_RW  = 0x10;   //just make it an output
    IO_BANK0_GPIO0_CTRL_RW = 6; //PIO

    PIO0_CTRL_RW = 1<<0;
	
	while(1)
	{
		sm_puts("Hello World from SM0 PIO!\n\r");
	}

    return(0);
}
