/*
#define MK_PTR_RW(x) (*(volatile int*)(x))

#define _RW   0x0000
#define _XOR  0x1000
#define _SET  0x2000
#define _CLR  0x3000

#define STK_CSR MK_PTR_RW(0xE000E010)
#define STK_RVR MK_PTR_RW(0xE000E014)
#define STK_CVR MK_PTR_RW(0xE000E018)

#define CLOCKS_BASE                 0x40008000
#define CLK_SYS_RESUS_CTRL_RW       MK_PTR_RW(CLOCKS_BASE+0x78+_RW)
#define CLK_REF_CTRL_RW             MK_PTR_RW(CLOCKS_BASE+0x30+_RW)
#define CLK_SYS_CTRL_RW             MK_PTR_RW(CLOCKS_BASE+0x3C+_RW)
#define CLK_PERI_CTRL_RW            MK_PTR_RW(CLOCKS_BASE+0x48+_RW)

#define XOSC_BASE                   0x40024000
#define XOSC_CTRL_RW                MK_PTR_RW(XOSC_BASE+0x00+_RW)
#define XOSC_STARTUP_RW             MK_PTR_RW(XOSC_BASE+0x0C+_RW)
#define XOSC_CTRL_SET               MK_PTR_RW(XOSC_BASE+0x00+_SET)
#define XOSC_STATUS_RW              MK_PTR_RW(XOSC_BASE+0x04+_RW)

#define RESETS_BASE                 0x4000C000
#define RESETS_RESET_CLR       MK_PTR_RW(RESETS_BASE+0x0+_CLR)
#define RESETS_RESET_DONE_RW   MK_PTR_RW(RESETS_BASE+0x8+_RW)

#define IO_BANK0_BASE               0x40014000

#define IO_BANK0_GPIO0_CTRL_RW      MK_PTR_RW(IO_BANK0_BASE+0x004+_RW)
#define IO_BANK0_GPIO1_CTRL_RW      MK_PTR_RW(IO_BANK0_BASE+0x00C+_RW)
#define IO_BANK0_GPIO25_CTRL_RW     MK_PTR_RW(IO_BANK0_BASE+0x0CC+_RW)

#define UART0_BASE                  0x40034000
#define UART0_BASE_UARTDR_RW        MK_PTR_RW(UART0_BASE+0x000+_RW)
#define UART0_BASE_UARTFR_RW        MK_PTR_RW(UART0_BASE+0x018+_RW)
#define UART0_BASE_UARTIBRD_RW      MK_PTR_RW(UART0_BASE+0x024+_RW)
#define UART0_BASE_UARTFBRD_RW      MK_PTR_RW(UART0_BASE+0x028+_RW)
#define UART0_BASE_UARTLCR_H_RW     MK_PTR_RW(UART0_BASE+0x02C+_RW)
#define UART0_BASE_UARTCR_RW        MK_PTR_RW(UART0_BASE+0x030+_RW)

#define SIO_BASE                    0xD0000000
#define SIO_GPIO_OE_CLR             MK_PTR_RW(SIO_BASE+0x28)
#define SIO_GPIO_OUT_SET            MK_PTR_RW(SIO_BASE+0x14)
#define SIO_GPIO_OUT_CLR            MK_PTR_RW(SIO_BASE+0x18)
#define SIO_GPIO_OUT_XOR            MK_PTR_RW(SIO_BASE+0x1C)
#define SIO_GPIO_OE_SET             MK_PTR_RW(SIO_BASE+0x24)
*/
#include "define.h"

void 	multicore_launch_core1 (void(*entry)(void));
int     multicore_fifo_pop_blocking(void);
void    multicore_fifo_push_blocking(int);

static void do_delay ( unsigned int x )
{
    unsigned int sec;

    for(sec=0;sec<x;)
    {
        if((STK_CSR & (1<<16))!=0)
        {
            sec++;
        }
    }
}


static unsigned int uart_recv ( void )
{
    while((UART0_BASE_UARTFR_RW & (1<<4))!=0);
    return (UART0_BASE_UARTDR_RW);
}

static void uart_send ( unsigned int x )
{
    while((UART0_BASE_UARTFR_RW & (1<<5))!=0);
    UART0_BASE_UARTDR_RW = x;
}

static void uart_puts(char *s)
{
	while(*s){
		uart_send(*s);
		s++;
	}
}

static void uart_gets(char *s)
{
	int ch;
	
	do {
		ch = uart_recv ();
		*s++ = ch;
	}while (ch!='\r');
}

static void clock_init ( void )
{
    CLK_SYS_RESUS_CTRL_RW = 0;
    XOSC_CTRL_RW          = 0xAA0;      //1 - 15MHZ
    XOSC_STARTUP_RW       = 47;         //straight from the datasheet
    XOSC_CTRL_SET         = 0xFAB000;   //enable
    while((XOSC_STATUS_RW & 0x80000000)==0);
    CLK_REF_CTRL_RW       = 2;          //XOSC
    CLK_SYS_CTRL_RW       = 0;          //reset/clk_ref
}

void reset_release(void)
{
    CLK_PERI_CTRL_RW = (1<<11)|(4<<5); // enable/xosc
    
    RESETS_RESET_CLR = (1<<5); //IO_BANK0
    while((RESETS_RESET_DONE_RW & (1<<5))==0);
    
    RESETS_RESET_CLR = (1<<8); //PADS_BANK0
    while((RESETS_RESET_DONE_RW & (1<<8))==0);
    
    RESETS_RESET_CLR = (1<<22); //UART0
    while((RESETS_RESET_DONE_RW & (1<<22))==0);
}

void uart_init(void)
{
    //(12000000/(16/115200)) = 6.514
    //0.514*64 = 32.666
    UART0_BASE_UARTIBRD_RW = 6;
    UART0_BASE_UARTFBRD_RW = 33;
    //0 11 1 0 0 0 0
    //0111 0000
    UART0_BASE_UARTLCR_H_RW = 0x70;  // 8bit fifo_en stop1
    UART0_BASE_UARTCR_RW    = (1<<9)|(1<<8)|(1<<0); // rxe/txe/uarten

    //GPIO 0 UART0 TX function 2
    //GPIO 1 UART0 RX function 2
    IO_BANK0_GPIO0_CTRL_RW  = 2;  //UART_TX
    IO_BANK0_GPIO1_CTRL_RW  = 2;  //UART_RX
}

void led_init(void)
{
    SIO_GPIO_OE_CLR  = (1<<25);
    SIO_GPIO_OUT_CLR = (1<<25); // OUTPUT "0"
    IO_BANK0_GPIO25_CTRL_RW = 5; //SIO
    SIO_GPIO_OE_SET         = (1<<25);
}

void systick_init(void)
{
	STK_CSR = 0x00000004;
    STK_RVR = 12000000-1;
    STK_CVR = 12000000-1;
    STK_CSR = 0x00000005;
}

void core1_main(void)
{
	int blink_width;
	int i;
	
	multicore_fifo_push_blocking(0x5a5a);
	systick_init();
    while(1)
    {
		blink_width = multicore_fifo_pop_blocking(); 
		uart_puts("receive data is ");
        uart_send(blink_width+'0');
        uart_puts(".\n\r");
        
		for(i=0;i<10;i++){
       		 SIO_GPIO_OUT_SET = (1<<25);
       		 do_delay(blink_width);
       		 SIO_GPIO_OUT_CLR = (1<<25);
       		 do_delay(blink_width);
       	}
    }
}


int main(void)
{
	char uart_buf[100];
	
    clock_init();
	reset_release();
	uart_init();
	led_init();

    multicore_launch_core1(core1_main);
    
    while(multicore_fifo_pop_blocking()!=0x5a5a);
    uart_puts("core1 has been waked up!\n\r");

	systick_init();

	uart_recv(); // dummy
	
    while(1)
    {
		do{
        uart_gets(uart_buf);
        } while ((uart_buf[0]<='0') || (uart_buf[0]>'9'));
        uart_puts("send data is ");
        uart_send(uart_buf[0]);
        uart_puts(".\n\r");
        multicore_fifo_push_blocking((int)(uart_buf[0]-'0'));
    }
    return(0);
}


