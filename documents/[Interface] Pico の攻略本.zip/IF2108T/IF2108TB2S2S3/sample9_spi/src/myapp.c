#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

#include "myapp.pio.h"			// myapp.pio: PIO ASM src name

int	main()
{
//	setup_default_uart();
	stdio_init_all();
	sleep_ms(3000);		// wait serial connection

	// todo	get	free state_machine
	PIO		pio		= pio0;

	uint	addr	= pio_add_program(pio, &pioasm_program);

	/////////////////////////////////////////////////////////////
	// PIN 0		OUT MOSI
	// PIN 1		IN  MISO
	// PIN 2		OUT SCK
	// PIN 3		OUT CS_N
	/////////////////////////////////////////////////////////////
	pioasm_exec(
		pio,
		0,			// sm
		addr,		// asm

		0,			// outpin base
		1,			// # of outpin

		1,			// inpin base
		1,			// # of inpin

		2,			// sidepin base
		2,			// # of sidepin

//		1.0			// 125MHz
		2.0			// 62.5MHz
//		4.0			// 31.25MHz
//		10.0		// 12.5MHz
//		12.50		// 10M
//		100.0		// 1.25MHz
//		125.0		// 1M
//		1000.0		// 125KHz
//		10000.0		// 12.5KHz
					// (min 1.9kHz)
	);

	while (true) {
		// put fifo
		if (pio_sm_is_tx_fifo_full(pio, 0) == false) {
			pio_sm_put_blocking(pio, 0, (uint32_t)0x805555F1);
		}

		// get fifo
		if (pio_sm_is_rx_fifo_empty(pio, 0) == false) {
			uint	data	= pio_sm_get_blocking(pio, 0);
			printf("RX %08x\n", data);
		}

		sleep_ms(500);
	}
}

