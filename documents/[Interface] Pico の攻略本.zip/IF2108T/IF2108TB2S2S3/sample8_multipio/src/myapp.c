#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

#include "myapp.pio.h"			// myapp.pio: PIO ASM src name

int	main()
{
//	setup_default_uart();
	stdio_init_all();
	sleep_ms(3000);		// wait serial connection

	// todo	get	free state_machine
	PIO		pio_0	= pio0;
	PIO		pio_1	= pio1;

	uint	addr0	= pio_add_program(pio_0, &pioasm_program);
	uint	addr1	= pio_add_program(pio_1, &pioasm_program);

	/////////////////////////////////////////////////////////////
	// PIN 5		OUT
	/////////////////////////////////////////////////////////////
	pioasm_exec(
		pio_0,
		0,		// sm
		addr0,	// asm

		5,		// outpin base
		1,		// # of outpin

		0,		// inpin base
		0,		// # of inpin

		0,		// sidepin base
		0,		// # of sidepin

//		1.0			// 125MHz
//		4.0			// 31.25MHz
//		10.0		// 12.5MHz
//		12.50		// 10M
//		100.0		// 1.25MHz
		125.0		// 1M
//		1000.0		// 125KHz
//		10000.0		// 12.5KHz
					// (min 1.9kHz)
	);

	/////////////////////////////////////////////////////////////
	// PIN 6		OUT
	/////////////////////////////////////////////////////////////
	pioasm_exec(
		pio_1,
		0,		// sm
		addr1,	// asm

		6,		// outpin base
		1,		// # of outpin

		0,		// inpin base
		0,		// # of inpin

		0,		// sidepin base
		0,		// # of sidepin

//		1.0			// 125MHz
//		4.0			// 31.25MHz
//		10.0		// 12.5MHz
		12.50		// 10M
//		100.0		// 1.25MHz
//		125.0		// 1M
//		1000.0		// 125KHz
//		10000.0		// 12.5KHz
					// (min 1.9kHz)
	);

	while (true) {
		sleep_ms(1000);
	}
}

