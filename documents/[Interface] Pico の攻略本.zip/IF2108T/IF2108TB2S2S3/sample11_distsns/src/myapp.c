#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

#include "myapp.pio.h"			// myapp.pio: PIO ASM src name

int	main()
{
//	setup_default_uart();
	stdio_init_all();
	sleep_ms(3000);		// wait serial connection

	// todo	get	free state_machine
	PIO		pio		= pio0;

	uint	addr	= pio_add_program(pio, &pioasm_program);

	/////////////////////////////////////////////////////////////
	// PIN 0	ECHO IN
	// PIN 1	TRIG OUT
	/////////////////////////////////////////////////////////////
	pioasm_exec(
		pio,
		0,		// sm
		addr,	// asm

		0,		// outpin base
		0,		// # of outpin

		0,		// inpin base
		1,		// # of inpin

		1,		// sidepin base
		1,		// # of sidepin

//		1.0			// 125MHz
//		4.0			// 31.25MHz
//		10.0		// 12.5MHz
		12.50		// 10M
//		100.0		// 1.25MHz
//		125.0		// 1M
//		1000.0		// 125KHz
//		10000.0		// 12.5KHz
					// (min 1.9kHz)
	);

	printf("init\n");
	sleep_ms(1000);

//	pio_sm_put_blocking(pio, 0, (uint32_t)((1 * 100 * 1000) / 4));		// timeout cuont; 100ms @1MHz
	pio_sm_put_blocking(pio, 0, (uint32_t)((10 * 100 * 1000) / 4));		// timeout cuont; 100ms @10MHz

	while (true) {
		// get fifo
		if (pio_sm_is_rx_fifo_empty(pio, 0) == false) {
			uint	data	= pio_sm_get_blocking(pio, 0);
			uint	clknum	= ((~data) + 1) * 5;
			printf("%d mm, %d clk, y %08x\n", clknum / 58, clknum, data);	// @10MHz, 0.1us
		}
	}

}

