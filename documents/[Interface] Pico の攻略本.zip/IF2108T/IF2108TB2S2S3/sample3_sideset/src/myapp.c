#include <stdio.h>

#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

#include "myapp.pio.h"			// myapp.pio: PIO ASM src name

int	main()
{
//	setup_default_uart();
	stdio_init_all();
	sleep_ms(3000);		// wait serial connection

	// todo	get	free state_machine
	PIO		pio		= pio0;

	uint	addr	= pio_add_program(pio, &pioasm_program);

	/////////////////////////////////////////////////////////////
	// PIN 5-10		OUT
	/////////////////////////////////////////////////////////////
	pioasm_exec(
		pio,
		0,		// sm
		addr,	// asm

		5,		// outpin base
		3,		// # of outpin

		0,		// inpin base
		0,		// # of inpin

		8,		// sidepin base
		3,		// # of sidepin

//		1.0			// 125MHz
//		4.0			// 31.25MHz
//		10.0		// 12.5MHz
//		12.50		// 10M
//		100.0		// 1.25MHz
		125.0		// 1M
//		1000.0		// 125KHz
//		10000.0		// 12.5KHz
					// (min 1.9kHz)
	);

	while (true) {
		sleep_ms(1000);
	}
}

