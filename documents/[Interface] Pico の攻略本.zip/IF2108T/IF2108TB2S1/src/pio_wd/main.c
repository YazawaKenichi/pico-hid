#include <stdint.h>
#include <stdio.h>

#include "hardware/clocks.h"
#include "hardware/irq.h"
#include "pico/stdlib.h"
#include "asm.pio.h"

#define LED_PIN 25

//! Watchdogの出力信号ピン
#define PIO_WD_PIN 15
//! カントダウンの周期。出力信号の周期と同等(10kHz)
#define PIO_WD_FREQ (10 * 1000)
//! 何カウントでタイムアウトさせるか(30ms)
#define PIO_WD_TIMEOUT 300


//! PIO版Watchdogの割り込みハンドラ
void pio0_ite() {
  irq_clear(PIO0_IRQ_0);
  pio0_hw->irq = 1;
  // 割り込みが視覚的に分かるようにLEDを光らせる
  gpio_put(LED_PIN, 1);

  while(1); // 無限ループ
}


int main() {
  stdio_init_all();

  gpio_init(LED_PIN);
  gpio_set_dir(LED_PIN, GPIO_OUT);
  gpio_put(LED_PIN, 0);

  PIO pio = pio0;
  const uint sm = 0;// 使用するSM

  // SM0からの割り込みを有効化します
  irq_set_exclusive_handler(PIO0_IRQ_0, pio0_ite);
  irq_set_enabled(PIO0_IRQ_0, true);
  pio0_hw->inte0 = PIO_IRQ0_INTE_SM0_BITS;

  // PIO版 watchdogの初期化
  const uint offset = pio_add_program(pio, &wd_program);
  wd_program_init(pio, sm, offset, PIO_WD_PIN, PIO_WD_FREQ);
  // 開始
  wd_reset(pio, sm, PIO_WD_TIMEOUT);

  int sleep_time = 0;
  while (true)
  {
    printf("sleep %dms\n", sleep_time);
    sleep_ms(sleep_time++);
    wd_reset(pio, sm, PIO_WD_TIMEOUT);
  }
}
