# PIO UART

PIO で UART を実装するプロジェクトです。

## ビルド方法

以下のビルドツールを利用します。

- GCC
- GCC Arm none eabi
- CMake
- Makefile

本ディレクトリ上でターミナルを開き、以下を実行して下さい。

```sh
mkdir build
cd build
cmake ..
make
```

上記のコマンドはPICO SDKをcloneするため、時間がかかります。

既にcloneしてあるPICO SDKを利用する場合は、cmakeのオプションでパスを指定して下さい

```sh
cmake .. -DPICO_SDK_PATH=<ディレクトリ>
```

## ファイル

- main.c : C言語ファイル
- asm.pio : PIOのプログラム
- CMakeLists.txt: CMake ファイルです. PICO SDKに依存します
