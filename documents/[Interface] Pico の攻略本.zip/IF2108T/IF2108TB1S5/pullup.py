import machine
import utime
pin_in = machine.Pin(18, machine.Pin.IN)
pin_out = machine.Pin(28, machine.Pin.OUT)

try:
    while True:
        machine.mem32[0x4001c04c] = 0x52
        pin_out.value(pin_in.value())
        utime.sleep(0.5)
        machine.mem32[0x4001c04c] = 0x56
        pin_out.value(pin_in.value())
        utime.sleep(0.5)
except KeyboardInterrupt:
    pass
