import machine
import utime
pin = machine.Pin(28, machine.Pin.OUT)
val=machine.mem32[0x4001c074]     #GPIO28
print (hex(val))
machine.mem32[0x4001c074] = 0x42    #2mA
pin.value(0)
val=machine.mem32[0x4001c074]
print (hex(val))
